使用STM32G070CBT6单片机开发的一款开发板，上面带有涂鸦云模组WBRU；
通过APP控制灯的亮灭。

MCU通过串口2和涂鸦云模组WBRU进行通信。
MCU通过串口1打印日志。
配网按键以及配网指示灯外接。
APP控制的LED灯是开发板自带的。

Using STM32G070CBT6 MCU development of a development board, with tuya cloud module WBRU;  
Control the light on and off through APP.  
 
MCU communicates with tuya cloud module WBRU through serial port 2.  
The MCU generates logs through serial port 1.  
Network keys and network indicator light are connected externally.  
The LED lamp controlled by APP comes with the development board.